package com.example.overlaymod

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max

class ShapesView(ctx: Context) : View(ctx) {
    class Shape(var r: RectF, var color: Int, var kind: Int, var alpha: Int)

    val shapes = mutableListOf<Shape>()
    var selected: Shape? = null
    var editing = true
    var onSelect: (() -> Unit)? = null

    // Proteção de cores
    val protectedColors = mutableListOf<Int>()
    var tolerance = 50
    var pickMode = false
    var onPicked: ((Int) -> Unit)? = null
    private var snap: IntArray? = null
    private var sw = 0
    private var sh = 0
    private var mask: Bitmap? = null
    private val maskPaint = Paint().apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        isFilterBitmap = true
    }
    private val full = RectF()

    private val dp = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 3 * dp
        pathEffect = DashPathEffect(floatArrayOf(16f, 10f), 0f)
    }
    private var mode = 0 // 0 nada, 1 mover, 2 redimensionar
    private var lx = 0f
    private var ly = 0f

    fun setSnapshot(a: IntArray, w: Int, h: Int) {
        snap = a; sw = w; sh = h
        rebuildMask()
    }

    /** Marca como "protegidos" os pontos da captura parecidos com as cores escolhidas. */
    fun rebuildMask() {
        val a = snap
        if (a == null || protectedColors.isEmpty()) { mask = null; invalidate(); return }
        val t2 = tolerance * tolerance
        val hit = BooleanArray(a.size)
        for (i in a.indices) {
            val p = a[i]
            val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            for (c in protectedColors) {
                val dr = r - ((c shr 16) and 255)
                val dg = g - ((c shr 8) and 255)
                val db = b - (c and 255)
                if (dr * dr + dg * dg + db * db <= t2) { hit[i] = true; break }
            }
        }
        val out = IntArray(a.size)
        for (y in 0 until sh) for (x in 0 until sw) {
            val i = y * sw + x
            // dilatação de 1 ponto para cobrir as bordas suavizadas da cor
            val m = hit[i] || (x > 0 && hit[i - 1]) || (x < sw - 1 && hit[i + 1]) ||
                (y > 0 && hit[i - sw]) || (y < sh - 1 && hit[i + sw])
            out[i] = if (m) 0xFF000000.toInt() else 0
        }
        var bm = mask
        if (bm == null || bm.width != sw || bm.height != sh) {
            bm = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
            mask = bm
        }
        bm.setPixels(out, 0, sw, 0, 0, sw, sh)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val m = mask
        full.set(0f, 0f, width.toFloat(), height.toFloat())
        for (s in shapes) {
            if (m != null) c.saveLayer(s.r, null)
            paint.style = Paint.Style.FILL
            paint.color = s.color
            paint.alpha = s.alpha
            when (s.kind) {
                0 -> c.drawRect(s.r, paint)
                1 -> c.drawRoundRect(s.r, 24 * dp, 24 * dp, paint)
                else -> c.drawOval(s.r, paint)
            }
            if (m != null) {
                c.drawBitmap(m, null, full, maskPaint) // apaga a forma onde há cor protegida
                c.restore()
            }
            if (editing && s === selected) {
                c.drawRect(s.r, outline)
                paint.color = Color.WHITE
                paint.alpha = 255
                c.drawCircle(s.r.right, s.r.bottom, 14 * dp, paint)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editing) return false
        if (pickMode) {
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                val a = snap
                if (a != null && width > 0 && height > 0) {
                    val x = (e.x / width * sw).toInt().coerceIn(0, sw - 1)
                    val y = (e.y / height * sh).toInt().coerceIn(0, sh - 1)
                    pickMode = false
                    onPicked?.invoke(a[y * sw + x])
                }
            }
            return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x; ly = e.y
                val sel = selected
                if (sel != null && hypot(e.x - sel.r.right, e.y - sel.r.bottom) < 30 * dp) {
                    mode = 2
                } else {
                    val hit = shapes.lastOrNull { it.r.contains(e.x, e.y) }
                    selected = hit
                    mode = if (hit != null) 1 else 0
                    if (hit != null) { shapes.remove(hit); shapes.add(hit) }
                }
                onSelect?.invoke()
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lx
                val dy = e.y - ly
                lx = e.x; ly = e.y
                selected?.let {
                    if (mode == 1) it.r.offset(dx, dy)
                    else if (mode == 2) {
                        it.r.right = max(it.r.left + 40 * dp, it.r.right + dx)
                        it.r.bottom = max(it.r.top + 40 * dp, it.r.bottom + dy)
                    }
                }
                invalidate()
            }
        }
        return true
    }
}
