package com.example.overlaymod

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Overlay Mod\n\n1. Permita \"Exibir sobre outros apps\".\n" +
                "2. Toque em Iniciar. O Android vai pedir para capturar a tela: " +
                "aceite e escolha \"Tela inteira\". Isso é usado só para detectar cores.\n" +
                "3. No painel: + Forma, arraste para mover, puxe a bolinha branca para redimensionar.\n" +
                "4. \"Pegar cor\" e toque numa cor da tela para protegê-la: as formas não cobrem essa cor.\n" +
                "5. Fixar: os toques passam pelas formas. Mudou a tela? Use \"Reanalisar\" na notificação."
            textSize = 16f
        })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { f() }
        })
        btn("Permitir sobreposição") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Iniciar") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permita a sobreposição primeiro", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
                val mpm = getSystemService(MediaProjectionManager::class.java)
                @Suppress("DEPRECATION")
                startActivityForResult(mpm.createScreenCaptureIntent(), 100)
            }
        }
        btn("Parar") { stopService(Intent(this, OverlayService::class.java)) }
        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 100) return
        val i = Intent(this, OverlayService::class.java)
        if (res == RESULT_OK && data != null) {
            i.putExtra("code", res)
            i.putExtra("data", data)
        } else {
            Toast.makeText(this, "Sem captura de tela: a proteção de cores fica desativada", Toast.LENGTH_LONG).show()
        }
        startForegroundService(i)
    }
}
