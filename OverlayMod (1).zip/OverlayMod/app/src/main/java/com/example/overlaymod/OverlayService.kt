package com.example.overlaymod

import android.app.*
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.*

class OverlayService : Service() {
    companion object { const val STEP = 4 } // a captura é analisada de 4 em 4 pixels

    private lateinit var wm: WindowManager
    private var sv: ShapesView? = null
    private var panel: LinearLayout? = null
    private var dot: FrameLayout? = null
    private lateinit var swatches: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var fullLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var fgStarted = false

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var capturing = false

    private val dp get() = resources.displayMetrics.density
    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val colors = intArrayOf(
        0xFF8E24AA.toInt(), 0xFFE53935.toInt(), 0xFF1E88E5.toInt(),
        0xFF43A047.toInt(), 0xFFFDD835.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt()
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") i?.getParcelableExtra("data")
        val newProj = data != null && projection == null
        if (!fgStarted || newProj) { startFg(newProj || projection != null); fgStarted = true }
        if (sv == null) setup()
        if (newProj) initProjection(i!!.getIntExtra("code", 0), data!!)
        when (i?.action) {
            "EDIT" -> setEditing(true)
            "SCAN" -> capture {}
        }
        return START_STICKY
    }

    private fun startFg(withProjection: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        fun act(code: Int, a: String) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(this, "ov")
            .setContentTitle("Overlay ativo")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(Notification.Action.Builder(0, "Editar", act(1, "EDIT")).build())
        if (withProjection) b.addAction(Notification.Action.Builder(0, "Reanalisar", act(2, "SCAN")).build())
        b.addAction(Notification.Action.Builder(0, "Parar", act(0, "STOP")).build())
        val n = b.build()
        val proj = 0x20            // FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        val special = 0x40000000   // FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, special or (if (withProjection) proj else 0))
        else if (Build.VERSION.SDK_INT >= 29 && withProjection) startForeground(1, n, proj)
        else startForeground(1, n)
    }

    // ---------- captura de tela ----------

    private fun initProjection(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val mp = mpm.getMediaProjection(code, data) ?: return
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { handler.post { releaseProjection() } }
            }, handler)
            val (w, h) = realSize()
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            vdisplay = mp.createVirtualDisplay(
                "cap", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
            projection = mp; reader = r
            if (sv?.protectedColors?.isNotEmpty() == true) handler.postDelayed({ capture {} }, 600)
        } catch (e: Exception) {
            toast("Não foi possível iniciar a captura: " + e.message)
        }
    }

    private fun releaseProjection() {
        vdisplay?.release(); vdisplay = null
        reader?.close(); reader = null
        projection = null
    }

    private fun realSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }

    /** Esconde tudo por um instante, tira uma "foto" da tela e atualiza a máscara. */
    private fun capture(done: () -> Unit) {
        val r = reader
        val v = sv
        if (r == null || v == null) { toast("Sem permissão de captura de tela"); return }
        if (capturing) return
        capturing = true
        while (true) { val old = r.acquireLatestImage() ?: break; old.close() }
        val views = listOfNotNull<View>(sv, panel, dot)
        views.forEach { it.alpha = 0f }
        var tries = 0
        fun attempt() {
            val im = r.acquireLatestImage()
            if (im == null && tries++ < 6) { handler.postDelayed({ attempt() }, 120); return }
            views.forEach { it.alpha = 1f }
            if (im != null) {
                try {
                    val pl = im.planes[0]
                    val buf = pl.buffer
                    val rs = pl.rowStride
                    val ps = pl.pixelStride
                    val w = im.width / STEP
                    val h = im.height / STEP
                    val a = IntArray(w * h)
                    for (y in 0 until h) {
                        val row = y * STEP * rs
                        for (x in 0 until w) {
                            val o = row + x * STEP * ps
                            a[y * w + x] = (0xFF shl 24) or
                                ((buf.get(o).toInt() and 255) shl 16) or
                                ((buf.get(o + 1).toInt() and 255) shl 8) or
                                (buf.get(o + 2).toInt() and 255)
                        }
                    }
                    v.setSnapshot(a, w, h)
                } finally { im.close() }
            }
            capturing = false
            done()
        }
        handler.postDelayed({ attempt() }, 200)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ---------- interface ----------

    private fun setup() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = ShapesView(this)
        sv = view
        load(view)

        // alpha 0.8 = máximo para o Android 12+ deixar o toque passar.
        fullLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, baseFlags, PixelFormat.TRANSLUCENT
        ).apply {
            alpha = 0.8f
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(view, fullLp)

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; textSize = 12f
            minHeight = 0; minimumHeight = 0
            setPadding((8 * dp).toInt(), (4 * dp).toInt(), (8 * dp).toInt(), (4 * dp).toInt())
            setOnClickListener { f() }
        }
        fun label(t: String) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 11f
            setPadding((4 * dp).toInt(), (6 * dp).toInt(), 0, 0)
        }

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pd = (6 * dp).toInt()
            setPadding(pd, pd, pd, pd)
            background = GradientDrawable().apply { setColor(0xDD222222.toInt()); cornerRadius = 16 * dp }
        }
        panel = p

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val handle = TextView(this).apply {
            text = "≡ arraste"; setTextColor(Color.WHITE); textSize = 13f
            setPadding((8 * dp).toInt(), (8 * dp).toInt(), (16 * dp).toInt(), (8 * dp).toInt())
        }
        val close = TextView(this).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 16f
            setPadding((12 * dp).toInt(), (6 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt())
            setOnClickListener { stopSelf() }
        }
        top.addView(handle); top.addView(close)
        p.addView(top)

        p.addView(btn("+ Forma") {
            val d = resources.displayMetrics
            val s = 200 * dp
            val cx = d.widthPixels / 2f
            val cy = d.heightPixels / 2f
            val sh = ShapesView.Shape(RectF(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2), colors[0], 1, 255)
            view.shapes.add(sh); view.selected = sh; view.invalidate(); sync()
        })
        p.addView(btn("Cor") {
            view.selected?.let { it.color = colors[(colors.indexOf(it.color) + 1) % colors.size]; view.invalidate() }
        })
        p.addView(btn("Formato") {
            view.selected?.let { it.kind = (it.kind + 1) % 3; view.invalidate() }
        })
        p.addView(label("Transparência"))
        seek = SeekBar(this).apply {
            max = 80; progress = 80
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, user: Boolean) {
                    if (user) { view.selected?.alpha = (v + 20) * 255 / 100; view.invalidate() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        p.addView(seek)
        p.addView(btn("Apagar") {
            view.shapes.remove(view.selected); view.selected = null; view.invalidate()
        })

        // --- proteção de cores ---
        p.addView(label("Cores protegidas (toque para remover)"))
        swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        p.addView(swatches)
        p.addView(btn("Pegar cor da tela") {
            if (view.protectedColors.size >= 6) toast("Máximo de 6 cores")
            else capture { if (reader != null) { view.pickMode = true; toast("Toque na cor que não deve ser coberta") } }
        })
        p.addView(label("Tolerância"))
        p.addView(SeekBar(this).apply {
            max = 100; progress = view.tolerance / 2
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, user: Boolean) {
                    if (user) { view.tolerance = v * 2; view.rebuildMask() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { save() }
            })
        })
        p.addView(btn("Reanalisar tela") { capture {} })
        p.addView(btn("Fixar") { setEditing(false) })

        view.onSelect = { sync() }
        view.onPicked = { c ->
            val rgb = c or 0xFF000000.toInt()
            if (!view.protectedColors.contains(rgb)) view.protectedColors.add(rgb)
            refreshSwatches(); view.rebuildMask(); save()
        }
        refreshSwatches()

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (16 * dp).toInt(); y = (60 * dp).toInt() }
        wm.addView(p, panelLp)

        // Ponto minúsculo no canto inferior direito, usado quando o painel está escondido.
        val d = FrameLayout(this).apply {
            val bolinha = View(context).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x40808080) }
            }
            addView(bolinha, FrameLayout.LayoutParams((8 * dp).toInt(), (8 * dp).toInt(), Gravity.CENTER))
            setOnClickListener { setEditing(true) }
            visibility = View.GONE
        }
        dot = d
        wm.addView(d, WindowManager.LayoutParams(
            (32 * dp).toInt(), (32 * dp).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.END })

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = panelLp.x; oy = panelLp.y }
                MotionEvent.ACTION_MOVE -> {
                    panelLp.x = ox + (e.rawX - sx).toInt()
                    panelLp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(p, panelLp)
                }
            }
            true
        }
    }

    private fun refreshSwatches() {
        val v = sv ?: return
        swatches.removeAllViews()
        for (c in v.protectedColors.toList()) {
            swatches.addView(View(this).apply {
                background = GradientDrawable().apply { setColor(c); setStroke((2 * dp).toInt(), Color.WHITE) }
                setOnClickListener {
                    v.protectedColors.remove(c); refreshSwatches(); v.rebuildMask(); save()
                }
            }, LinearLayout.LayoutParams((30 * dp).toInt(), (30 * dp).toInt()).apply {
                setMargins((3 * dp).toInt(), (4 * dp).toInt(), (3 * dp).toInt(), (4 * dp).toInt())
            })
        }
    }

    private fun sync() {
        sv?.selected?.let { seek.progress = (it.alpha * 100 / 255 - 20).coerceIn(0, 80) }
    }

    private fun setEditing(on: Boolean) {
        val v = sv ?: return
        v.editing = on
        v.pickMode = false
        if (!on) v.selected = null
        fullLp.flags = if (on) baseFlags else baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(v, fullLp)
        panel?.visibility = if (on) View.VISIBLE else View.GONE
        dot?.visibility = if (on) View.GONE else View.VISIBLE
        if (!on) save()
        v.invalidate()
    }

    private fun save() {
        val v = sv ?: return
        val s = v.shapes.joinToString(";") {
            "${it.r.left},${it.r.top},${it.r.right},${it.r.bottom},${it.color},${it.kind},${it.alpha}"
        }
        getSharedPreferences("shapes", MODE_PRIVATE).edit()
            .putString("data", s)
            .putString("prot", v.protectedColors.joinToString(","))
            .putInt("tol", v.tolerance)
            .apply()
    }

    private fun load(v: ShapesView) {
        val sp = getSharedPreferences("shapes", MODE_PRIVATE)
        val s = sp.getString("data", "") ?: ""
        for (part in s.split(";").filter { it.isNotBlank() }) {
            val a = part.split(",")
            if (a.size < 7) continue
            v.shapes.add(ShapesView.Shape(
                RectF(a[0].toFloat(), a[1].toFloat(), a[2].toFloat(), a[3].toFloat()),
                a[4].toInt(), a[5].toInt(), a[6].toInt()
            ))
        }
        (sp.getString("prot", "") ?: "").split(",").filter { it.isNotBlank() }
            .forEach { v.protectedColors.add(it.toInt()) }
        v.tolerance = sp.getInt("tol", 50)
    }

    override fun onDestroy() {
        save()
        releaseProjection()
        sv?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        dot?.let { wm.removeView(it) }
        sv = null; panel = null; dot = null
        super.onDestroy()
    }
}
