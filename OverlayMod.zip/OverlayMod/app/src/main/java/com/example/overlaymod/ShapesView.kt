package com.example.overlaymod

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max

class ShapesView(ctx: Context) : View(ctx) {
    class Shape(var r: RectF, var color: Int, var kind: Int, var alpha: Int)

    val shapes = mutableListOf<Shape>()
    var selected: Shape? = null
    var editing = true
    var onSelect: (() -> Unit)? = null

    private val dp = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 3 * dp
        pathEffect = DashPathEffect(floatArrayOf(16f, 10f), 0f)
    }
    private var mode = 0 // 0 nada, 1 mover, 2 redimensionar
    private var lx = 0f
    private var ly = 0f

    override fun onDraw(c: Canvas) {
        for (s in shapes) {
            paint.style = Paint.Style.FILL
            paint.color = s.color
            paint.alpha = s.alpha
            when (s.kind) {
                0 -> c.drawRect(s.r, paint)
                1 -> c.drawRoundRect(s.r, 24 * dp, 24 * dp, paint)
                else -> c.drawOval(s.r, paint)
            }
            if (editing && s === selected) {
                c.drawRect(s.r, outline)
                paint.color = Color.WHITE
                paint.alpha = 255
                c.drawCircle(s.r.right, s.r.bottom, 14 * dp, paint)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editing) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x; ly = e.y
                val sel = selected
                if (sel != null && hypot(e.x - sel.r.right, e.y - sel.r.bottom) < 30 * dp) {
                    mode = 2
                } else {
                    val hit = shapes.lastOrNull { it.r.contains(e.x, e.y) }
                    selected = hit
                    mode = if (hit != null) 1 else 0
                    if (hit != null) { shapes.remove(hit); shapes.add(hit) }
                }
                onSelect?.invoke()
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lx
                val dy = e.y - ly
                lx = e.x; ly = e.y
                selected?.let {
                    if (mode == 1) it.r.offset(dx, dy)
                    else if (mode == 2) {
                        it.r.right = max(it.r.left + 40 * dp, it.r.right + dx)
                        it.r.bottom = max(it.r.top + 40 * dp, it.r.bottom + dy)
                    }
                }
                invalidate()
            }
        }
        return true
    }
}
