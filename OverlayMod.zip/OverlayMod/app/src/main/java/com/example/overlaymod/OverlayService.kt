package com.example.overlaymod

import android.app.*
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var sv: ShapesView? = null
    private var panel: LinearLayout? = null
    private lateinit var controls: LinearLayout
    private lateinit var editBtn: Button
    private lateinit var seek: SeekBar
    private lateinit var fullLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private val dp get() = resources.displayMetrics.density
    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val colors = intArrayOf(
        0xFF8E24AA.toInt(), 0xFFE53935.toInt(), 0xFF1E88E5.toInt(),
        0xFF43A047.toInt(), 0xFFFDD835.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt()
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startFg()
        if (sv == null) setup()
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "ov")
            .setContentTitle("Overlay ativo")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(Notification.Action.Builder(0, "Parar", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, 0x40000000) // specialUse
        else startForeground(1, n)
    }

    private fun setup() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = ShapesView(this)
        sv = view
        load(view)

        // Janela de tela cheia. alpha 0.8 = máximo para o Android 12+ deixar o toque passar.
        fullLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, baseFlags, PixelFormat.TRANSLUCENT
        ).apply {
            alpha = 0.8f
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(view, fullLp)

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; textSize = 12f; setOnClickListener { f() }
        }

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pd = (6 * dp).toInt()
            setPadding(pd, pd, pd, pd)
            background = GradientDrawable().apply { setColor(0xDD222222.toInt()); cornerRadius = 16 * dp }
        }
        panel = p

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val handle = TextView(this).apply {
            text = "≡ arraste"; setTextColor(Color.WHITE); textSize = 13f
            setPadding((8 * dp).toInt(), (8 * dp).toInt(), (16 * dp).toInt(), (8 * dp).toInt())
        }
        val close = TextView(this).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 16f
            setPadding((12 * dp).toInt(), (6 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt())
            setOnClickListener { stopSelf() }
        }
        top.addView(handle); top.addView(close)
        p.addView(top)

        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        controls.addView(btn("+ Forma") {
            val d = resources.displayMetrics
            val s = 200 * dp
            val cx = d.widthPixels / 2f
            val cy = d.heightPixels / 2f
            val sh = ShapesView.Shape(RectF(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2), colors[0], 1, 255)
            view.shapes.add(sh); view.selected = sh; view.invalidate(); sync()
        })
        controls.addView(btn("Cor") {
            view.selected?.let { it.color = colors[(colors.indexOf(it.color) + 1) % colors.size]; view.invalidate() }
        })
        controls.addView(btn("Formato") {
            view.selected?.let { it.kind = (it.kind + 1) % 3; view.invalidate() }
        })
        seek = SeekBar(this).apply {
            max = 80; progress = 80
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, user: Boolean) {
                    if (user) { view.selected?.alpha = (v + 20) * 255 / 100; view.invalidate() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        controls.addView(seek)
        controls.addView(btn("Apagar") {
            view.shapes.remove(view.selected); view.selected = null; view.invalidate()
        })
        controls.addView(btn("Fixar") { setEditing(false) })
        p.addView(controls)

        editBtn = btn("Editar") { setEditing(true) }
        editBtn.visibility = View.GONE
        p.addView(editBtn)

        view.onSelect = { sync() }

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (16 * dp).toInt(); y = (120 * dp).toInt() }
        wm.addView(p, panelLp)

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = panelLp.x; oy = panelLp.y }
                MotionEvent.ACTION_MOVE -> {
                    panelLp.x = ox + (e.rawX - sx).toInt()
                    panelLp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(p, panelLp)
                }
            }
            true
        }
    }

    private fun sync() {
        sv?.selected?.let { seek.progress = (it.alpha * 100 / 255 - 20).coerceIn(0, 80) }
    }

    private fun setEditing(on: Boolean) {
        val v = sv ?: return
        v.editing = on
        if (!on) v.selected = null
        fullLp.flags = if (on) baseFlags else baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(v, fullLp)
        controls.visibility = if (on) View.VISIBLE else View.GONE
        editBtn.visibility = if (on) View.GONE else View.VISIBLE
        if (!on) save()
        v.invalidate()
    }

    private fun save() {
        val v = sv ?: return
        val s = v.shapes.joinToString(";") {
            "${it.r.left},${it.r.top},${it.r.right},${it.r.bottom},${it.color},${it.kind},${it.alpha}"
        }
        getSharedPreferences("shapes", MODE_PRIVATE).edit().putString("data", s).apply()
    }

    private fun load(v: ShapesView) {
        val s = getSharedPreferences("shapes", MODE_PRIVATE).getString("data", "") ?: ""
        for (part in s.split(";").filter { it.isNotBlank() }) {
            val a = part.split(",")
            if (a.size < 7) continue
            v.shapes.add(ShapesView.Shape(
                RectF(a[0].toFloat(), a[1].toFloat(), a[2].toFloat(), a[3].toFloat()),
                a[4].toInt(), a[5].toInt(), a[6].toInt()
            ))
        }
    }

    override fun onDestroy() {
        save()
        sv?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        sv = null; panel = null
        super.onDestroy()
    }
}
