package com.example.overlaymod

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Overlay Mod\n\n1. Permita \"Exibir sobre outros apps\".\n" +
                "2. Toque em Iniciar e abra o app que quiser.\n" +
                "3. No painel flutuante: + Forma, arraste para mover, " +
                "puxe a bolinha branca para redimensionar.\n" +
                "4. Toque em Fixar: os toques passam pelas formas."
            textSize = 16f
        })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { f() }
        })
        btn("Permitir sobreposição") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Iniciar") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permita a sobreposição primeiro", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
                startForegroundService(Intent(this, OverlayService::class.java))
            }
        }
        btn("Parar") { stopService(Intent(this, OverlayService::class.java)) }
        setContentView(root)
    }
}
